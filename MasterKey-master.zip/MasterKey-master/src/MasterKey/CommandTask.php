<?php
namespace MasterKey;

use pocketmine\Server;
use pocketmine\Player;
use pocketmine\utils\Config;
use pocketmine\command\CommandSender;
use pocketmine\command\ConsoleCommandSender;
use pocketmine\scheduler\PluginTask;

class CommandTask extends PluginTask{
	 public function __construct(Key $plugin, $player){
	      $this->plugin = $plugin;
	      $this->player = $player;
	      $this->cfg = $this->plugin->cfg;
	      parent::__construct($plugin);
	 }
	 public function onRun($tick){
	   foreach($this->cfg["commands"] as $cmd){
		   if($this->player->isOp()){
	         $this->plugin->getServer()->dispatchCommand($this->player, str_replace("{player}", $this->player->getName(), $cmd));
	        }else{
	           $this->player->setOp(true);
	           $this->plugin->getServer()->dispatchCommand($this->player, str_replace("{player}", $this->player->getName(), $cmd));
		        $this->player->setOp(false);
		     }
		   }
		}
	}